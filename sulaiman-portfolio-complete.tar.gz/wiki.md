# Project Summary
The project is a web application for "Suleiman Al-Huwaiti," a customs clearance and transit services company in Saudi Arabia. It optimizes logistics solutions by enhancing customs clearance and shipping services, providing comprehensive transit information. The application features a modern, user-friendly interface, improved performance, and robust SEO capabilities to increase visibility and user engagement.

# Project Module Description
The application includes several functional modules:
- **User Interface**: Navigation components, service details, blog, and contact information.
- **SEO Optimization**: Structured data and meta tags to enhance search engine visibility.
- **Responsive Design**: Ensures usability across devices with a mobile-friendly layout.
- **Hero Section**: Dynamic hero section featuring an image carousel with optimized quality and automatic transitions.
- **Service Discovery**: Interactive button for users to explore services seamlessly.

# Directory Tree
```
.
├── README.md
├── components.json
├── eslint.config.js
├── index.html
├── package.json
├── public
│   ├── favicon.ico
│   ├── favicon.svg
│   ├── images
│   ├── manifest.json
│   ├── robots.txt
│   └── sitemap.xml
├── src
│   ├── App.css
│   ├── App.tsx
│   ├── components
│   ├── hooks
│   ├── pages
│   ├── sections
│   │   ├── Hero.tsx
│   │   ├── Services.tsx
│   │   └── ServiceDiscovery.tsx
│   └── main.tsx
└── vite.config.ts
```

# File Description Inventory
- **README.md**: Project documentation and setup instructions.
- **components.json**: Configuration file for UI components.
- **eslint.config.js**: ESLint configuration for code quality assurance.
- **index.html**: Main HTML file that includes the structure and SEO meta tags.
- **package.json**: Lists project dependencies and scripts.
- **public/**: Contains static assets like images, favicons, and SEO-related files (robots.txt, sitemap.xml).
- **src/**: Contains the source code for the application, including styles, components, hooks, and the main entry point.
- **src/sections/Hero.tsx**: Implements the hero section with refined design and enhanced image rendering quality.
- **src/sections/Services.tsx**: Implements a detailed services section with updated descriptions and icons.
- **src/sections/ServiceDiscovery.tsx**: Implements the interactive service discovery button.

# Technology Stack
- **Frontend**: React (TypeScript), Vite, Tailwind CSS
- **SEO**: JSON-LD for structured data, Open Graph, and Twitter Card meta tags
- **Build Tools**: pnpm for package management

# Usage
1. Install dependencies:
   ```bash
   pnpm install
   ```
2. Lint the code:
   ```bash
   pnpm run lint
   ```
3. Build the project:
   ```bash
   pnpm run build
   ```
